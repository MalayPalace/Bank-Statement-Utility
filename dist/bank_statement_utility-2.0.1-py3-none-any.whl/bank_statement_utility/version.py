# Will point to the latest version
__version__ = "2.0.1"

# version specific constants
__version_2_0_1__ = "2.0.1"
__version_2_0_0__ = "2.0.0"
__version_1_2_1__ = "1.2.1"