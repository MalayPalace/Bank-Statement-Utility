# To maintain version information
__version__ = "1.1.0"
