
class IParser:

    def get_next_data(self):
        pass

    def close(self):
        pass