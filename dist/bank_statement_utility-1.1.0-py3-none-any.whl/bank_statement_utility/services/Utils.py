def remove_comma(value: str):
    if value:
        return value.replace(",", "")
    return value
