import os

bank_names = ['HDFC', 'KOTAK', 'SBI', 'BOB', 'IDBI']
account_type = ['Saving', 'Current', 'Creditcard']

COMMA = ","
TAB = "\t"
APP_CONFIG_PATH = os.path.expanduser("~") + "/.local/share/bank-statement-app/"
# APP_CONFIG_PATH = "./config/" # For local Testing