class BankStatementInterface:

    def get_record(self):
        pass

    def map_record(self, value_dict):
        pass
