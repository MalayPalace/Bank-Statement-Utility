import bank_statement_utility.main as main_app


def main():
    """
    Entry point through installed module
    """
    main_app.main()
